IDA* nodes expanded 269
IDA* time 112 milliseconds

DFID nodes expanded 12300543
DFID time 14314 milliseconds

IDA* nodes expanded 283
IDA* time 31 milliseconds

DFID nodes expanded 4457841
DFID time 2535 milliseconds

IDA* nodes expanded 493
IDA* time 60 milliseconds

DFID nodes expanded 39442736
DFID time 20066 milliseconds
