public class Heuristic {

    public Heuristic() {
    }

    public int manhattan_distance(STPState compare_state, STPState goal) {
        return 0;
    }
}
