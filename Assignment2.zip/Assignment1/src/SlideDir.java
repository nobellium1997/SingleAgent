public enum SlideDir {
    Up, Down, Left, Right;
}
